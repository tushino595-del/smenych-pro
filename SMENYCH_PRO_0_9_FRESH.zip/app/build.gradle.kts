plugins { id("com.android.application") }

android {
    namespace = "com.smenych.pro"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.smenych.pro"
        minSdk = 26
        targetSdk = 35
        versionCode = 9
        versionName = "0.9-test"
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
