package com.smenych.pro;

import android.Manifest;
import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.webkit.GeolocationPermissions;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.util.Log;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

public final class MainActivity extends Activity {
    private static final String TAG = "SmenychPro";
    private static final String ORIGIN = "https://appassets.androidplatform.net";
    private static final int LOCATION_REQUEST = 101;
    private WebView webView;
    private String pendingGeoOrigin;
    private GeolocationPermissions.Callback pendingGeoCallback;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(10,12,23));
        getWindow().setNavigationBarColor(Color.rgb(10,12,23));
        try {
            webView = new WebView(this);
            webView.setBackgroundColor(Color.rgb(10,12,23));
            WebSettings s = webView.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setDatabaseEnabled(true);
            s.setAllowFileAccess(false);
            s.setAllowContentAccess(false);
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
            s.setGeolocationEnabled(true);
            s.setDefaultTextEncodingName("UTF-8");
            webView.setWebViewClient(new WebViewClient() {
                @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                    if (request.getUrl().toString().equals(ORIGIN + "/index.html")) {
                        try {
                            return new WebResourceResponse("text/html", "UTF-8", getAssets().open("index.html"));
                        } catch (Exception e) { Log.e(TAG,"Failed to open asset",e); }
                    }
                    return null;
                }
            });
            webView.setWebChromeClient(new WebChromeClient() {
                @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                    if (hasLocationPermission()) callback.invoke(origin,true,false);
                    else {
                        pendingGeoOrigin = origin;
                        pendingGeoCallback = callback;
                        requestPermissions(new String[]{Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_REQUEST);
                    }
                }
                @Override public void onGeolocationPermissionsHidePrompt() {
                    pendingGeoCallback = null;
                    pendingGeoOrigin = null;
                }
            });
            setContentView(webView);
            webView.loadUrl(ORIGIN+"/index.html");
        } catch (Exception e) {
            Log.e(TAG,"Startup error",e);
            TextView error = new TextView(this);
            error.setTextColor(Color.WHITE);
            error.setBackgroundColor(Color.rgb(10,12,23));
            error.setPadding(24,36,24,24);
            error.setText("СМЕНЫЧ PRO: ошибка запуска\n" + e.getClass().getSimpleName() + ": " + e.getMessage());
            setContentView(error);
        }
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED
            || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED;
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        if (requestCode==LOCATION_REQUEST && pendingGeoCallback!=null) {
            pendingGeoCallback.invoke(pendingGeoOrigin,hasLocationPermission(),false);
            pendingGeoCallback=null; pendingGeoOrigin=null;
        }
    }
    @Override public void onBackPressed() {
        if (webView!=null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if (webView!=null) { webView.destroy(); webView=null; }
        super.onDestroy();
    }
}
